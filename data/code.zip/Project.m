function [] = Project(learnTack1,learnTack2,ConvertTrack)
    addpath('VoiceBox/');
    doPlot=false;
    [y1,~,~,~]=readwav(learnTack1,'r',-1,0);
    [y2,~,~,~]=readwav(learnTack2,'r',-1,0);
    
    pol=[];
    for factor=0.6:0.1:1
        pol=[pol;learning(y1,y2,factor,doPlot)];
    end
    %Mean of pol of a lot of windows
    polMean=mean(pol,1);
    
    if(doPlot)
        close all
        x1=0:0.1:300;
        y1=polyval(polMean,x1);
        figure
        plot(x1,y1);
    end
    
    [y3,fs3,wmode3,~]=readwav(ConvertTrack,'r',-1,0);
    newINTime=conversion(y3,polMean,doPlot);
    writewav(newINTime,fs3,strcat('output.wav'),wmode3);
end

function [newINTime]=conversion(file, pol,doPlot)
    if(doPlot)
        close all
        figure
        spectrogram(file(:,1),800,[],256,16000,'yaxis')
        figure
        plot(file)
    end
    [fft,~]=getFFT40(file);
    copyArrayFreq3=fft;
    for i=1:size(fft,2)
        for j=1:size(fft,1)
            if(j>1)
                newFreq=round(polyval(pol,j));
                if(newFreq<=size(fft,1))
                    fft(newFreq,i)=copyArrayFreq3(j,i);
                end
            end
        end
    end
    newFFT=fft;
    newINTime=getIFFT40(newFFT,doPlot);
    if(doPlot)
        figure
        plot(newINTime)
        figure
        spectrogram(newINTime,800,[],256,16000,'yaxis')
    end
end

function [pol]=learning(first,second,factor,doPlot)
    [~,conjfft1]=getFFT(first, factor);
    [~,conjfft2]=getFFT(second, factor);
    
    totalTime=size(conjfft2,2);
    numFrequences=size(conjfft2,1);
    if(doPlot)
        close all
        figure
        spectrogram(first(:,1),800,[],256,16000,'yaxis')
        figure
        spectrogram(second(:,1),800,[],256,16000,'yaxis')
        % contour o contourf per grafo 2d colori
        %contour([1:totalTime],[1:numFrequences],arrayFreq1)
        %figure
        %contour([1:totalTime],[1:numFrequences],arrayFreq2)
    end
    N=8;
    
    [~,sortingIndices] = sort(conjfft1,'descend');
    newArrayF1=zeros(size(conjfft1));
    firstN1=sortingIndices(1:N,:);
    for j=1:(size(newArrayF1,2))
        newArrayF1(sortingIndices(1:N,j),j)=1;
    end
    if(doPlot)
        figure
        contour(1:totalTime,1:numFrequences,newArrayF1);
    end
    
    [~,sortingIndices] = sort(conjfft2,'descend');
    newArrayF2=zeros(size(conjfft2));
    firstN2=sortingIndices(1:N,:);
    for j=1:(size(newArrayF2,2))
        newArrayF2(sortingIndices(1:N,j),j)=1;
    end
    if(doPlot)
        figure
        contour(1:totalTime,1:numFrequences,newArrayF2);
    end

    %Cut Frequencies
    ref1=reshape(firstN1,1,[]);
    ref2=reshape(firstN2,1,[]);
    %110 is empirically take from graph
    %ref2(ref1 >110) = [];
    %ref1(ref1 >110) = [];
    %ref2(ref2 >110) = [];
    pol=polyfit(ref1,ref2,2);
    
    if(doPlot)
        x1=min(ref1):0.1:max(ref2);
        y1=polyval(pol,x1);
        figure
        plot(ref1,ref2,'o',x1,y1);
    end
end

function [fftdata,fftdataConj] = getFFT(array, factor)
    sound=mean(array,2);
    frames=enframe(sound, round(800*factor));%this is like millisecond
    frames=transpose(frames);
    fftdata=rfft(frames);%here every column rappresent the fft of a frame
    fftdataConj=(fftdata.*conj(fftdata));
end

function [fftdata,fftdataConj] = getFFT40(array)
    sound=mean(array,2);
    frames=enframe(sound, 800);%this is like millisecond
    frames=transpose(frames);
    fftdata=rfft(frames);%here every column rappresent the fft of a frame
    fftdataConj=(fftdata.*conj(fftdata));
end

function [vectorFunction] = getIFFT40(arrayFreq,doPlot)
    %The dimensions of the output matrix
    matrixDimension=size(arrayFreq);
    %The number of column and the number of frame
    col=matrixDimension(2);
    %Costruction of a vector from the matrix
    vectorFunction=[];
    for i=1:col,
        vectorFunction=[vectorFunction;irfft(arrayFreq(:,i))];
    end
    if(doPlot)
        plot(vectorFunction)
    end
end